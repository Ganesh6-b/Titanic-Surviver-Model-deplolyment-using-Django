from django.apps import AppConfig


class TitanicsurvivorsConfig(AppConfig):
    name = 'titanicsurvivors'
