from django.shortcuts import render
import pandas as pd
import joblib
model = joblib.load("C:/Users/ADMIN/Data Science Projects/Titanic Dataset Predictions/TitanicModel.pkl")

# Create your views here.
def home(request):
    if request.method == 'POST':
        temp = {}
        temp['Pclass'] = request.POST['Pclass']
        temp['Fare'] = request.POST['Fare']
        temp['Age'] = request.POST['Age']
        temp['Embarked'] = request.POST['Embarked']
        temp['Sex'] = request.POST['Sex']
        temp['SibSp'] = request.POST['SibSp']
        temp['Parch'] = request.POST['Parch']

        testdata = pd.DataFrame({'x' : temp}).transpose()
        scoreval = model.predict(testdata)[0]
        context = {"scoreval" : scoreval}
        return render(request, "home.html", context)
    return render(request, "home.html")